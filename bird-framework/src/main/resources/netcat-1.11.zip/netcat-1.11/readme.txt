步骤1：下载netcat,地址：https://eternallybored.org/misc/netcat/


步骤2：将解压后的单个文件全部拷贝到C:\Windows\System32的文件夹下
Tips：注意不是拷贝整个文件夹，而是文件夹里面的全部文件。

步骤3：打开命令行即可使用nc.


ubuntu: nc -l 9000

window命令为：nc -l -p 9000
